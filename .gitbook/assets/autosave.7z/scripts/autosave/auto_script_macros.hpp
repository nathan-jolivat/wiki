#define AUTO_SETTINGS(TYPE,SETTING) TYPE(missionConfigFile >> "Autosave_Settings" >> SETTING)
