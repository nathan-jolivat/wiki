#define true 1
#define false 0

/*
    File: Master.hpp
    Author: Thomas Sturk

    Description: The variable table for the autosave script
*/

class Autosave_Settings {

	/*Set true to false the option you want change*/
	/*In this brackets [] you can find the default settings e.g. [default = false] or [default = 4]*/

/*autosave time*/
		autoSaveSleep = 10; // Sleep time between save data, scaled to minutes [default = 10]
		saveTrafic = true; // Save your trafic by create random time added to your sleep time, scaled to minutes [default = true]
		randomTime = 5; // If saveTrafic is enabled, random time added time to your saveSleep between 0 and your selected value, scaled to minutes [default = 5]

/*autosave systems*/
		messageWhenPlayerDataAreSave = true; // Make hint when player data are save [default = true]
		saveDataLog = false; // Create a log when player are his data save [default = false]
};
